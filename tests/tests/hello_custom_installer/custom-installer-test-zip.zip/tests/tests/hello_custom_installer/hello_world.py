#!/usr/bin/python3.4
# -*- coding: utf-8 -*-
def main():
    print('Hello world!')

if u'__main__' == __name__:
   main()